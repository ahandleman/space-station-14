Station Architect map draft

Open station-plan.svg to review the geometry.
project.station.json restores the editable design and its requirements.
Resources contains the map and companion gameMap descriptor.
Review systems-manifest.json before loading the map in SS14.
Generation and scalar validation do not certify an operational station.
